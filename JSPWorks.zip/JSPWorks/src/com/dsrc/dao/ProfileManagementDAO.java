package com.dsrc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dsrc.bean.ChangePasswordBean;
import com.dsrc.bean.LoginBean;
import com.dsrc.bean.RegisterBean;
import com.dsrc.exceptions.CustomerBusinessExcetion;
import com.dsrc.exceptions.CustomerException;

public class ProfileManagementDAO {
	public RegisterBean validateLogin(LoginBean logBean) throws CustomerException
	{
		RegisterBean reg=new RegisterBean();

    try{
		Class.forName("com.mysql.jdbc.Driver");
       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tempdb","root","dsrc");
	 PreparedStatement ps=con.prepareStatement("select * from userdetails where loginname=? and password=?"); 
        ps.setString(1,logBean.getLoginName());
        ps.setString(2,logBean.getPassword());
        ResultSet rs=ps.executeQuery();
        while(rs.next()){
        
        	   reg.setLoginName(rs.getString(1));	
	              reg.setPassword(rs.getString(2));	
	              reg.setAge(rs.getInt(3));	
	              reg.setAddress(rs.getString(4));	
	              reg.setEmail(rs.getString(5));	
        	
        }
    } 
    catch (Exception e1) {
		throw new CustomerException("Please Enter valid details");
	}
    return reg;
		
	
	
}
	public boolean registerUser(RegisterBean regBean) throws CustomerException
	{
		boolean result=false;

        try{
			Class.forName("com.mysql.jdbc.Driver");
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tempdb","root","dsrc");
		 PreparedStatement ps=con.prepareStatement("insert into userdetails values(?,?,?,?,?)"); 
            ps.setString(1,regBean.getLoginName());
            ps.setString(2,regBean.getPassword());
            ps.setInt(3,regBean.getAge());
            ps.setString(4,regBean.getAddress());
            ps.setString(5,regBean.getEmail());

            int res=ps.executeUpdate();
            if(res>0){
            	result=true;
            }

        } catch (Exception e1) {
			throw new CustomerException("Already Existing");
   		}
     
		return result;
		
	}
	public RegisterBean viewProfile(RegisterBean regBean) throws SQLException, CustomerBusinessExcetion
	{
		  RegisterBean rb=new RegisterBean();

          try{
				Class.forName("com.mysql.jdbc.Driver");
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tempdb","root","dsrc");
			 PreparedStatement ps=con.prepareStatement("select * from userdetails where loginname=? and password=?"); 
		        ps.setString(1,regBean.getLoginName());
		        ps.setString(2,regBean.getPassword());

		        ResultSet rs=ps.executeQuery();
		        while(rs.next()){
		              rb.setLoginName(rs.getString(1));	
		              rb.setPassword(rs.getString(2));	
		              rb.setAge(rs.getInt(3));	
		              rb.setAddress(rs.getString(4));	
		              rb.setEmail(rs.getString(5));	
		           

		        }
		    } catch (ClassNotFoundException e1) {
                    throw new CustomerBusinessExcetion(e1.getMessage());
				}catch (SQLException e1) {
					 throw new CustomerBusinessExcetion(e1.getMessage());
				}
		return rb;

		
		
	}
	
	public boolean editUser(RegisterBean regBean) throws CustomerBusinessExcetion
	{
		System.out.println(regBean.getAge());
		System.out.println(regBean.getAddress());
		System.out.println(regBean.getEmail());
		System.out.println(regBean.getLoginName());
		System.out.println(regBean.getPassword());
		
			boolean result=false;

         try{
				Class.forName("com.mysql.jdbc.Driver");
		       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/tempdb","root","dsrc");
			   PreparedStatement ps=con.prepareStatement("update userdetails set age=?,address=?,email=? where loginname=? and password=?"); 
		        ps.setInt(1,regBean.getAge());
		        ps.setString(2,regBean.getAddress());
		        ps.setString(3,regBean.getEmail());
		        ps.setString(4,regBean.getLoginName());
		        ps.setString(5,regBean.getPassword());

	            int res=ps.executeUpdate();
	            if(res>0)
	            {
	            	result=true;
	            }
		    } catch (ClassNotFoundException e1) {
                   throw new CustomerBusinessExcetion(e1.getMessage());
				}
         catch (SQLException e1) {
			 throw new CustomerBusinessExcetion(e1.getMessage());
		}
		return result;
		
	}
	public boolean changePassword(ChangePasswordBean cBean)
	{
		
		// Do the logic for  modifying the records in database.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return false;
		
	}
	
}
