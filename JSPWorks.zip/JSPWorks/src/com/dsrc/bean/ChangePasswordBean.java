package com.dsrc.bean;

public class ChangePasswordBean {

	/*
	 * 	Use this bean for password change .
	 * 	
	 *  Create variables for loginid ,old password , new password and confirm password
	 *  Create getters and setters..
	 * 
	 * */
	String loginname;
	String oldpassword;
	String newpassword;
	String confirmpassword;
	public String getLoginid() {
		return loginname;
	}
	public void setLoginid(String loginid) {
		this.loginname = loginid;
	}
	public String getOldpassword() {
		return oldpassword;
	}
	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}
	public String getNewpassword() {
		return newpassword;
	}
	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

}
