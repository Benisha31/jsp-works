package com.dsrc.bean;

public class RegisterBean 
{
	// Create the private variables for registration 
	// Create proper getters and Setters.
	// Use this bean for registration , view profile and update profiles functionalities..
	private String loginName;
	private String password;
	private int age;
	private String address;
	private String email;
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginid) {
		this.loginName = loginid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
