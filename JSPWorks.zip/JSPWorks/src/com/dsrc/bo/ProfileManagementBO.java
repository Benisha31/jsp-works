package com.dsrc.bo;

import java.sql.SQLException;

import com.dsrc.bean.ChangePasswordBean;
import com.dsrc.bean.LoginBean;
import com.dsrc.bean.RegisterBean;
import com.dsrc.dao.ProfileManagementDAO;
import com.dsrc.exceptions.CustomerBusinessExcetion;
import com.dsrc.exceptions.CustomerException;

public class ProfileManagementBO 
{
	public RegisterBean validateLogin(LoginBean logBean) throws CustomerBusinessExcetion, CustomerException
	{
		if(logBean.getLoginName()==null || logBean.getPassword()==null ){
			throw new CustomerBusinessExcetion("Please enter valid details");
			}
     
		return new ProfileManagementDAO().validateLogin(logBean);
		
	}
	public boolean registerUser(RegisterBean regBean) throws CustomerBusinessExcetion, CustomerException
	{
		
		if(regBean.getLoginName()==null || regBean.getPassword()==null || regBean.getAddress()==null||regBean.getEmail()==null){
			throw new CustomerBusinessExcetion("Please enter valid details");
			}
		if(regBean.getAge()<18){
			throw new CustomerBusinessExcetion("Invalid age");}
		return new ProfileManagementDAO().registerUser(regBean);
		
		
		
		
	}
	public RegisterBean viewProfile(RegisterBean login) throws SQLException, CustomerBusinessExcetion 
	{
		
		return new ProfileManagementDAO().viewProfile(login);
		
	}
	
	public boolean editUser(RegisterBean regBean) throws CustomerBusinessExcetion
	{
		
		// Do the logic for data entry validations and after successful validation call the DAO -> editUser method for modifying the records in database.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return new ProfileManagementDAO().editUser(regBean);
		
	}
	public boolean changePassword(ChangePasswordBean cBean)
	{
		
		// Do the logic for data entry validations and after successful validation call the DAO -> changePassword method for modifying the records in database.
		// In case of validation Errors , raise your own exception with customized message using ProfileMgmtException class.
		
		return false;
		
	}
	
	
}
