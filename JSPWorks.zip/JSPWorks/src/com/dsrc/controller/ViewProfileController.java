package com.dsrc.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dsrc.bean.RegisterBean;
import com.dsrc.bo.ProfileManagementBO;
import com.dsrc.exceptions.CustomerBusinessExcetion;

/**
 * Servlet implementation class ViewProfileController
 */
@WebServlet("/ViewProfileController")
public class ViewProfileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RegisterBean reg=new RegisterBean();
		try{
			reg.setLoginName(request.getParameter("name"));
			reg.setPassword(request.getParameter("pass"));
		
		}catch(NumberFormatException e1){
			RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
			request.setAttribute("errorReason","Please enter valid details");
			rd.forward(request, response);
		}
			ProfileManagementBO bo=new ProfileManagementBO();
			RegisterBean res;
			try {
				res = bo.viewProfile(reg);
				if(res.getLoginName()!=null){
					RequestDispatcher rd=request.getRequestDispatcher("ViewProfile.jsp");
					request.setAttribute("Details",res);
					rd.forward(request, response);
				}else{
					RequestDispatcher rd=request.getRequestDispatcher("ViewProfile.jsp");
					request.setAttribute("errorReason", "failed");
					rd.forward(request, response);
				}
			} 
			catch (SQLException | CustomerBusinessExcetion e) {
				RequestDispatcher rd=request.getRequestDispatcher("ViewProfile.jsp");
				request.setAttribute("errorReason", e.getMessage());
				rd.forward(request, response);
			}
			
		}	
	
	}


