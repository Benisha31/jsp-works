package com.dsrc.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dsrc.bean.LoginBean;
import com.dsrc.bean.RegisterBean;
import com.dsrc.bo.ProfileManagementBO;
import com.dsrc.exceptions.CustomerBusinessExcetion;
import com.dsrc.exceptions.CustomerException;

/**
 * Servlet implementation class EditController
 */
@WebServlet("/EditController")
public class EditController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		 HttpSession session=request.getSession();
		 RegisterBean login=new RegisterBean();
         String name=session.getAttribute("name").toString();
         String pass=session.getAttribute("pass").toString();

       try{
		    login.setLoginName(name);
			login.setPassword(pass);
		    login.setAge(Integer.parseInt(request.getParameter("age")));
		    login.setAddress(request.getParameter("address"));
		    login.setEmail(request.getParameter("email"));
		}catch(NumberFormatException e1){
			RequestDispatcher rd=request.getRequestDispatcher("EditProfile.jsp");
			request.setAttribute("errorReason","Please enter valid details");
			rd.forward(request, response);
		}
			ProfileManagementBO bo=new ProfileManagementBO();
			try{
			boolean res=bo.editUser(login);
			
			
			if(res){
				RequestDispatcher rd=request.getRequestDispatcher("EditProfile.jsp");
				//session.setAttribute("details", res);
                  request.setAttribute("errorReason", "success");
				rd.forward(request, response);
			}else{
				RequestDispatcher rd=request.getRequestDispatcher("EditProfile.jsp");
				request.setAttribute("errorReason", "failed");
				rd.forward(request, response);
			}
		}catch(CustomerBusinessExcetion e){
			RequestDispatcher rd=request.getRequestDispatcher("EditProfile.jsp");
			request.setAttribute("errorReason", e.getMessage());
			rd.forward(request, response);
		}
				}

}
