package com.dsrc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dsrc.bean.RegisterBean;
import com.dsrc.bo.ProfileManagementBO;
import com.dsrc.exceptions.CustomerBusinessExcetion;
import com.dsrc.exceptions.CustomerException;

/**
 * Servlet implementation class RegistrationController
 */
@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RegisterBean register=new RegisterBean();
	try{
		register.setLoginName(request.getParameter("name"));
		register.setPassword(request.getParameter("pass"));
		register.setAge(Integer.parseInt(request.getParameter("age")));
		register.setAddress(request.getParameter("address"));
		register.setEmail(request.getParameter("email"));
	}catch(NumberFormatException e1){
		RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
		request.setAttribute("errorReason","Please enter valid details");
		rd.forward(request, response);
	}
		ProfileManagementBO bo=new ProfileManagementBO();
		try{
		boolean res=bo.registerUser(register);
		if(res){
			RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
			request.setAttribute("loginName", register.getLoginName());
			rd.forward(request, response);
		}else{
			RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
			request.setAttribute("errorReason", "Registration failed");
			rd.forward(request, response);
		}
	}catch(CustomerBusinessExcetion|CustomerException e){
		RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
		request.setAttribute("errorReason", e.getMessage());
		rd.forward(request, response);
	}
	}

}
