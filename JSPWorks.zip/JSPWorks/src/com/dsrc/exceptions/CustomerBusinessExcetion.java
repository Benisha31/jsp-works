package com.dsrc.exceptions;

public class CustomerBusinessExcetion extends Exception {
  public CustomerBusinessExcetion(String msg){
	  super(msg);
  }
}
